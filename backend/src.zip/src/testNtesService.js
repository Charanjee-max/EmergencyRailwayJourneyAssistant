const ntesService =
    require("./train/ntes.service");


async function test() {

    try {

        console.log(
            "\n========================================"
        );

        console.log(
            "       ERJA - NTES SERVICE TEST"
        );

        console.log(
            "========================================\n"
        );


        const result =
            await ntesService
                .getTrainRunningStatus(
                    "18189",
                    "16-Sep-2026"
                );


        console.log(
            "\n========================================"
        );

        console.log(
            "TRAIN"
        );

        console.log(
            "========================================"
        );

        console.log(
            JSON.stringify(
                result.train,
                null,
                2
            )
        );


        console.log(
            "\n========================================"
        );

        console.log(
            "RUNNING STATUS"
        );

        console.log(
            "========================================"
        );

        console.log(
            JSON.stringify(
                result.status,
                null,
                2
            )
        );


        console.log(
            "\n========================================"
        );

        console.log(
            "STOPS"
        );

        console.log(
            "========================================"
        );

        console.log(
            "Total stops:",
            result.stops.length
        );


        if (
            result.stops.length > 0
        ) {

            console.log(
                "\nFirst stop:"
            );

            console.log(
                JSON.stringify(
                    result.stops[0],
                    null,
                    2
                )
            );


            console.log(
                "\nLast stop:"
            );

            console.log(
                JSON.stringify(
                    result.stops[
                        result.stops.length - 1
                    ],
                    null,
                    2
                )
            );
        }


        console.log(
            "\n========================================"
        );

        console.log(
            "NTES SERVICE TEST COMPLETED"
        );

        console.log(
            "========================================\n"
        );

    } catch (error) {

        console.error(
            "\n========================================"
        );

        console.error(
            "❌ NTES SERVICE TEST FAILED"
        );

        console.error(
            "========================================\n"
        );

        console.error(
            error.message
        );

        if (error.response) {

            console.error(
                "HTTP Status:",
                error.response.status
            );
        }

        process.exitCode = 1;
    }
}


test();