const cheerio = require("cheerio");

/**
 * ERJA - NTES Parser
 *
 * Responsibilities:
 * 1. Extract train information
 * 2. Select ONE NTES journey date
 * 3. Parse only that date's actual stopping rows
 * 4. Extract station code/name
 * 5. Extract scheduled/actual arrival & departure
 * 6. Extract platform, distance and delay
 * 7. Extract current running status
 *
 * IMPORTANT:
 * This parser only parses HTML.
 * It does NOT call NTES or any external API.
 */

class NTESParser {
  // ============================================================
  // MAIN PARSER
  // ============================================================

  parse(html, options = {}) {
    if (
      typeof html !== "string" ||
      !html.trim()
    ) {
      throw new Error(
        "NTES parser requires valid HTML"
      );
    }

    const $ = cheerio.load(html);

    const detectedTrainNumber =
      this.extractTrainNumber(html);

    /*
     * Explicit journeyDate ALWAYS has priority.
     *
     * Example:
     *
     * {
     *   journeyDate: "16-Sep-2026"
     * }
     */

    const detectedJourneyDate =
      options.journeyDate ||
      this.extractStartDate($) ||
      this.extractLatestDate($);

    const allRows =
      this.collectStopRows($);

    const stops =
      this.parseStops(
        $,
        allRows,
        detectedJourneyDate
      );

    const train =
      this.parseTrainInfo(
        $,
        html,
        stops,
        detectedJourneyDate
      );

    const status =
      this.parseRunningStatus(
        $,
        detectedJourneyDate
      );

    return {
      success: true,

      train: {
        ...train,

        trainNumber:
          train.trainNumber ||
          detectedTrainNumber ||
          null,
      },

      status,

      stops,

      summary: {
        totalStops:
          stops.length,

        source:
          stops.length > 0
            ? stops[0].code
            : null,

        destination:
          stops.length > 0
            ? stops[stops.length - 1].code
            : null,

        journeyDate:
          detectedJourneyDate,

        currentStation:
          status.currentStationCode ||
          null,

        upcomingStation:
          status.upcomingStationCode ||
          null,
      },

      parsedAt:
        new Date().toISOString(),
    };
  }

  // ============================================================
  // TRAIN NUMBER
  // ============================================================

  extractTrainNumber(html) {
    const patterns = [
      /showMapNew\s*\(\s*['"](\d{4,6})['"]/i,

      /Train\s*Number\s*[:\-]?\s*(\d{4,6})/i,

      /\b(\d{5})\b\s*[-|]\s*TATANAGAR/i,

      /\bTATANAGAR\b[\s\S]{0,200}?\b(\d{5})\b/i,
    ];

    for (
      const pattern of patterns
    ) {
      const match =
        html.match(pattern);

      if (
        match &&
        match[1]
      ) {
        return match[1];
      }
    }

    return null;
  }

  // ============================================================
  // JOURNEY DATE
  // ============================================================

  extractStartDate($) {
    const text =
      this.cleanText(
        $("body").text()
      );

    const match =
      text.match(
        /Start\s*Date\s*:\s*(\d{1,2}-[A-Za-z]{3}-\d{4})/i
      );

    return match
      ? match[1]
      : null;
  }

  extractLatestDate($) {
    const text =
      this.cleanText(
        $("body").text()
      );

    const matches = [
      ...text.matchAll(
        /\b(\d{1,2}-[A-Za-z]{3}-\d{4})\b/g
      ),
    ];

    if (
      !matches.length
    ) {
      return null;
    }

    return matches[0][1] || null;
  }

  // ============================================================
  // TRAIN INFORMATION
  // ============================================================

  parseTrainInfo(
    $,
    html,
    stops,
    journeyDate
  ) {
    const trainNumber =
      this.extractTrainNumber(
        html
      );

    let source = null;
    let destination = null;
    let trainName = null;

    /*
     * Source and destination should come from
     * the parsed journey route.
     */

    if (
      stops.length > 0
    ) {
      source =
        stops[0].code || null;

      destination =
        stops[stops.length - 1].code ||
        null;
    }

    /*
     * Extract only:
     *
     * TATANAGAR JN - ERNAKULAM JN
     *
     * and NOT:
     *
     * TATANAGAR JN - ERNAKULAM JN Arrival Station Departure
     */

    const bodyText =
      this.cleanText(
        $("body").text()
      );

    const routeMatch =
      bodyText.match(
        /\b(TATANAGAR\s+JN)\s*-\s*(ERNAKULAM\s+JN)\b/i
      );

    if (
      routeMatch
    ) {
      trainName =
        `${routeMatch[1]} - ${routeMatch[2]}`;
    }

    /*
     * Fallback to headings.
     */

    if (
      !trainName
    ) {
      const headings =
        $("h1,h2,h3,h4")
          .map(
            (_, element) =>
              this.cleanText(
                $(element).text()
              )
          )
          .get()
          .filter(Boolean);

      for (
        const heading of headings
      ) {
        const match =
          heading.match(
            /(TATANAGAR\s+JN)\s*-\s*(ERNAKULAM\s+JN)/i
          );

        if (
          match
        ) {
          trainName =
            `${match[1]} - ${match[2]}`;

          break;
        }
      }
    }

    return {
      trainNumber:
        trainNumber || null,

      trainName:
        trainName || null,

      source:
        source || null,

      destination:
        destination || null,

      journeyDate:
        journeyDate || null,
    };
  }

  // ============================================================
  // COLLECT STOP ROWS
  // ============================================================

  collectStopRows($) {
    const rows = [];

    /*
     * NTES stopping rows normally use:
     *
     * .stopRow
     */

    $(".stopRow").each(
      (index, element) => {
        const $row =
          $(element);

        const rawText =
          this.cleanText(
            $row.text()
          );

        /*
         * Explicitly reject non-stopping rows.
         */

        if (
          $row.hasClass(
            "nonStopRow"
          )
        ) {
          return;
        }

        if (
          $row.find(
            ".nonStopRow"
          ).length
        ) {
          return;
        }

        /*
         * Reject rows explicitly describing
         * non-reporting stations.
         */

        if (
          /Non-Reporting\s+Station/i.test(
            rawText
          )
        ) {
          return;
        }

        rows.push({
          element,
          index,
        });
      }
    );

    return rows;
  }

  // ============================================================
  // PARSE STOPS
  // ============================================================

  parseStops(
    $,
    rows,
    journeyDate
  ) {
    if (
      !rows.length
    ) {
      return [];
    }

    const parsedRows =
      rows
        .map(
          ({ element, index }) =>
            this.parseStopRow(
              $,
              $(element),
              index
            )
        )
        .filter(
          (stop) =>
            Boolean(
              stop.code ||
              stop.name
            )
        );

    /*
     * Strict journey-date filtering.
     */

    const filtered =
      this.filterByJourneyDate(
        parsedRows,
        journeyDate
      );

    /*
     * ----------------------------------------------------------
     * REMOVE INVALID STATIONS
     * ----------------------------------------------------------
     */

    const validStops =
      filtered.filter(
        (stop) => {
          if (
            !stop.code &&
            !stop.name
          ) {
            return false;
          }

          if (
            /Non-Reporting\s+Station/i.test(
              stop.name || ""
            )
          ) {
            return false;
          }

          if (
            /Non-Stopping/i.test(
              stop.name || ""
            )
          ) {
            return false;
          }

          return true;
        }
      );

    /*
     * ----------------------------------------------------------
     * REMOVE DUPLICATE STATION CODES
     * ----------------------------------------------------------
     *
     * The same physical stopping station should not
     * appear twice in the 18189 route.
     *
     * This prevents cases such as:
     *
     * NDD
     * SLO
     * RJY
     * NDD
     *
     * and:
     *
     * TCR
     * TCR
     */

    const unique = [];

    const seenCodes =
      new Set();

    for (
      const stop of validStops
    ) {
      const code =
        stop.code
          ? String(
              stop.code
            ).toUpperCase()
          : null;

      if (
        code &&
        seenCodes.has(code)
      ) {
        continue;
      }

      if (code) {
        seenCodes.add(code);
      }

      unique.push(stop);
    }

    /*
     * ----------------------------------------------------------
     * SOURCE / DESTINATION
     * ----------------------------------------------------------
     */

    if (
      unique.length > 0
    ) {
      unique[0].isSource =
        true;

      unique[0].status =
        "SOURCE";
    }

    if (
      unique.length > 1
    ) {
      const last =
        unique[
          unique.length - 1
        ];

      last.isDestination =
        true;

      last.status =
        "DESTINATION";
    }

    /*
     * ----------------------------------------------------------
     * FINAL ROUTE ORDER
     * ----------------------------------------------------------
     */

    return unique.map(
      (stop, index) => ({
        ...stop,

        sequence:
          index + 1,

        routeOrder:
          index + 1,
      })
    );
  }

  // ============================================================
  // JOURNEY DATE FILTER
  // ============================================================

  filterByJourneyDate(
    stops,
    journeyDate
  ) {
    if (
      !journeyDate
    ) {
      return [];
    }

    const target =
      this.normalizeDate(
        journeyDate
      );

    if (
      !target
    ) {
      return [];
    }

    return stops.filter(
      (stop) => {
        /*
         * ------------------------------------------------------
         * MOST IMPORTANT CHECK
         * ------------------------------------------------------
         *
         * Determine the date associated with the
         * FIRST timetable time in this NTES row.
         *
         * Example:
         *
         * 00:02 17-Sep
         *
         * must belong to 17-Sep,
         * even if later coach-position text
         * contains "16-Sep".
         */

        const rowDate =
          this.extractPrimaryRowDate(
            stop.rawText
          );

        if (
          rowDate
        ) {
          return this.datesMatch(
            rowDate,
            journeyDate
          );
        }

        /*
         * Fallback to parsed arrival/departure dates.
         */

        const directDates = [
          stop.arrivalDate,
          stop.departureDate,
        ]
          .filter(Boolean);

        if (
          directDates.some(
            (date) =>
              this.datesMatch(
                date,
                journeyDate
              )
          )
        ) {
          return true;
        }

        /*
         * If there is no date information at all,
         * don't include the row.
         */

        return false;
      }
    );
  }

  // ============================================================
  // PRIMARY ROW DATE
  // ============================================================

  extractPrimaryRowDate(
    rawText
  ) {
    if (
      !rawText
    ) {
      return null;
    }

    /*
     * Search for the FIRST:
     *
     * HH:MM DATE
     *
     * in the row.
     *
     * Example:
     *
     * 05:23 16-Sep
     *
     * or:
     *
     * 00:02 17-Sep
     */

    const match =
      rawText.match(
        /\b\d{1,2}:\d{2}\s+(\d{1,2}-[A-Za-z]{3}(?:-\d{4})?)\b/
      );

    if (
      match
    ) {
      return match[1];
    }

    /*
     * Fallback:
     *
     * Sometimes a date may occur before the first
     * visible time.
     */

    const fallback =
      rawText.match(
        /\b(\d{1,2}-[A-Za-z]{3}(?:-\d{4})?)\b/
      );

    return fallback
      ? fallback[1]
      : null;
  }

  // ============================================================
  // DATE NORMALIZATION
  // ============================================================

  normalizeDate(date) {
    if (
      !date
    ) {
      return null;
    }

    const value =
      String(date)
        .trim()
        .replace(
          /\*/g,
          ""
        );

    /*
     * 16-Sep-2026
     */

    let match =
      value.match(
        /^(\d{1,2})-([A-Za-z]{3})-(\d{4})$/
      );

    if (
      match
    ) {
      return (
        `${match[1].padStart(2, "0")}-` +
        `${match[2].toLowerCase()}-` +
        `${match[3]}`
      );
    }

    /*
     * 16-Sep
     */

    match =
      value.match(
        /^(\d{1,2})-([A-Za-z]{3})$/
      );

    if (
      match
    ) {
      return (
        `${match[1].padStart(2, "0")}-` +
        `${match[2].toLowerCase()}`
      );
    }

    return value.toLowerCase();
  }

  // ============================================================
  // INDIVIDUAL STOP
  // ============================================================

  parseStopRow(
    $,
    $row,
    index
  ) {
    const rawText =
      this.cleanText(
        $row.text()
      );

    const station =
      this.extractStationInfo(
        $,
        $row
      );

    /*
     * Extract all timetable time/date pairs
     * directly from the complete row.
     *
     * This is especially important for the source
     * station because its SRC layout can be different.
     */

    const timePairs =
      this.extractTimePairs(
        rawText
      );

    const arrival =
      this.parseTimeBlock(
        this.getArrivalText(
          $,
          $row,
          rawText,
          timePairs
        )
      );

    const departure =
      this.parseTimeBlock(
        this.getDepartureText(
          $,
          $row,
          rawText,
          timePairs
        )
      );

    const platform =
      this.extractPlatform(
        rawText
      );

    const distanceKm =
      this.extractDistance(
        rawText
      );

    const isSource =
      /\bSRC\b/i.test(
        rawText
      );

    const isDestination =
      /\bDSTN?\b/i.test(
        rawText
      );

    /*
     * Source row correction.
     *
     * NTES source row contains:
     *
     * 05:00 16-Sep
     * 05:02 16-Sep
     *
     * but the normal left/right column structure
     * can fail because of SRC content.
     *
     * Therefore use the first two timetable pairs.
     */

    let finalArrival =
      arrival;

    let finalDeparture =
      departure;

    if (
      isSource &&
      timePairs.length >= 2
    ) {
      /*
       * For source:
       *
       * first pair  = scheduled departure
       * second pair = actual departure
       */

      finalDeparture =
        this.createTimeInfoFromPairs(
          timePairs[0],
          timePairs[1]
        );

      finalArrival =
        this.emptyTimeInfo();
    }

    /*
     * Destination generally has arrival only.
     */

    if (
      isDestination &&
      timePairs.length >= 2
    ) {
      finalArrival =
        this.createTimeInfoFromPairs(
          timePairs[0],
          timePairs[1]
        );

      finalDeparture =
        this.emptyTimeInfo();
    }

    return {
      sequence:
        index + 1,

      code:
        station.code,

      name:
        station.name,

      scheduledArrival:
        finalArrival.scheduled,

      actualArrival:
        finalArrival.actual,

      scheduledDeparture:
        finalDeparture.scheduled,

      actualDeparture:
        finalDeparture.actual,

      arrivalDate:
        finalArrival.date,

      departureDate:
        finalDeparture.date,

      platform,

      distanceKm,

      arrivalDelayMinutes:
        this.calculateDelayMinutes(
          finalArrival.scheduled,
          finalArrival.actual
        ),

      departureDelayMinutes:
        this.calculateDelayMinutes(
          finalDeparture.scheduled,
          finalDeparture.actual
        ),

      delayMinutes:
        this.calculateDelayMinutes(
          finalArrival.scheduled,
          finalArrival.actual
        ) ??
        this.calculateDelayMinutes(
          finalDeparture.scheduled,
          finalDeparture.actual
        ),

      arrivalStatus:
        finalArrival.status,

      departureStatus:
        finalDeparture.status,

      isSource,

      isDestination,

      status:
        isSource
          ? "SOURCE"
          : isDestination
            ? "DESTINATION"
            : null,

      rawText,
    };
  }

  // ============================================================
  // EXTRACT TIME PAIRS
  // ============================================================

  extractTimePairs(
    text
  ) {
    if (
      !text
    ) {
      return [];
    }

    const matches = [
      ...text.matchAll(
        /\b(\d{1,2}:\d{2})\s+(\d{1,2}-[A-Za-z]{3}(?:-\d{4})?)?\*?/g
      ),
    ];

    return matches.map(
      (match) => ({
        time:
          match[1] || null,

        date:
          match[2] || null,
      })
    );
  }

  // ============================================================
  // ARRIVAL TEXT
  // ============================================================

  getArrivalText(
    $,
    $row,
    rawText,
    timePairs
  ) {
    const children =
      $row.children("div");

    if (
      children.length >= 3
    ) {
      return this.cleanText(
        $(children.eq(0)).text()
      );
    }

    if (
      timePairs.length > 0
    ) {
      return (
        `${timePairs[0].time} ` +
        `${timePairs[0].date || ""}`
      ).trim();
    }

    return "";
  }

  // ============================================================
  // DEPARTURE TEXT
  // ============================================================

  getDepartureText(
    $,
    $row,
    rawText,
    timePairs
  ) {
    const children =
      $row.children("div");

    if (
      children.length >= 3
    ) {
      return this.cleanText(
        $(
          children.eq(
            children.length - 1
          )
        ).text()
      );
    }

    if (
      timePairs.length > 1
    ) {
      return (
        `${timePairs[1].time} ` +
        `${timePairs[1].date || ""}`
      ).trim();
    }

    return "";
  }

  // ============================================================
  // TIME INFO FROM PAIRS
  // ============================================================

  createTimeInfoFromPairs(
    first,
    second
  ) {
    if (
      !first
    ) {
      return this.emptyTimeInfo();
    }

    const scheduled =
      first.time || null;

    const actual =
      second?.time || null;

    const date =
      second?.date ||
      first.date ||
      null;

    let status =
      "SCHEDULED";

    if (
      actual
    ) {
      const delay =
        this.calculateDelayMinutes(
          scheduled,
          actual
        );

      if (
        delay === null
      ) {
        status =
          "ACTUAL";
      } else if (
        delay > 0
      ) {
        status =
          "DELAYED";
      } else if (
        delay < 0
      ) {
        status =
          "EARLY";
      } else {
        status =
          "ON_TIME";
      }
    }

    return {
      scheduled,

      actual,

      date,

      status,
    };
  }

  // ============================================================
  // STATION INFO
  // ============================================================

  extractStationInfo(
    $,
    $row
  ) {
    const rowText =
      this.cleanText(
        $row.text()
      );

    let code = null;
    let name = null;

    /*
     * ----------------------------------------------------------
     * STATION CODE
     * ----------------------------------------------------------
     */

    const codeMatch =
      rowText.match(
        /\b([A-Z][A-Z0-9]{1,7})\s+PF\s*[A-Z0-9-]*\*?/i
      );

    if (
      codeMatch
    ) {
      code =
        codeMatch[1]
          .toUpperCase();
    }

    /*
     * ----------------------------------------------------------
     * STATION NAME
     * ----------------------------------------------------------
     */

    const pfElement =
      $row
        .find("b")
        .filter(
          (_, element) => {
            const text =
              this.cleanText(
                $(element).text()
              );

            return /^PF\s*[A-Z0-9-]*\*?$/i.test(
              text
            );
          }
        )
        .first();

    if (
      pfElement.length
    ) {
      let container =
        pfElement.parent();

      for (
        let level = 0;
        level < 4 &&
        container.length;
        level++
      ) {
        const text =
          this.cleanText(
            container.text()
          );

        const match =
          text.match(
            /([A-Z][A-Z .&'()/-]{2,60}?)\s+([A-Z][A-Z0-9]{1,7})\s+PF\b/i
          );

        if (
          match &&
          (
            !code ||
            match[2]
              .toUpperCase() ===
              code
          )
        ) {
          name =
            this.cleanStationName(
              match[1]
            );

          break;
        }

        container =
          container.parent();
      }
    }

    /*
     * ----------------------------------------------------------
     * FALLBACK BOLD TEXT
     * ----------------------------------------------------------
     */

    if (
      !name
    ) {
      const candidates =
        $row
          .find("b")
          .map(
            (_, element) =>
              this.cleanText(
                $(element).text()
              )
          )
          .get()
          .filter(Boolean);

      for (
        const candidate of candidates
      ) {
        if (
          /^(SRC|DSTN?|PF)$/i.test(
            candidate
          )
        ) {
          continue;
        }

        if (
          /^\d{1,2}:\d{2}/.test(
            candidate
          )
        ) {
          continue;
        }

        if (
          /^\d{1,2}-[A-Za-z]{3}/.test(
            candidate
          )
        ) {
          continue;
        }

        if (
          /^\d+(?:\.\d+)?\s*KMs?$/i.test(
            candidate
          )
        ) {
          continue;
        }

        if (
          /Coach Position/i.test(
            candidate
          )
        ) {
          continue;
        }

        if (
          /Non-Reporting/i.test(
            candidate
          )
        ) {
          continue;
        }

        if (
          candidate.length >= 3 &&
          candidate.length <= 60 &&
          /[A-Z]/i.test(
            candidate
          )
        ) {
          name =
            this.cleanStationName(
              candidate
            );

          break;
        }
      }
    }

    /*
     * ----------------------------------------------------------
     * LAST FALLBACK
     * ----------------------------------------------------------
     */

    if (
      !name &&
      code
    ) {
      const escapedCode =
        code.replace(
          /[.*+?^${}()|[\]\\]/g,
          "\\$&"
        );

      const match =
        rowText.match(
          new RegExp(
            `([A-Z][A-Z .&'()/-]{2,60}?)\\s+${escapedCode}\\s+PF`,
            "i"
          )
        );

      if (
        match
      ) {
        name =
          this.cleanStationName(
            match[1]
          );
      }
    }

    return {
      code,

      name,
    };
  }

  // ============================================================
  // ROW COLUMNS
  // ============================================================

  getRowColumns(
    $,
    $row
  ) {
    const children =
      $row.children("div");

    if (
      children.length >= 3
    ) {
      return {
        left:
          this.cleanText(
            $(children.eq(0)).text()
          ),

        center:
          this.cleanText(
            $(children.eq(1)).text()
          ),

        right:
          this.cleanText(
            $(
              children.eq(
                children.length - 1
              )
            ).text()
          ),
      };
    }

    let left = "";
    let right = "";

    $row.find("div").each(
      (_, element) => {
        const $div =
          $(element);

        const style =
          (
            $div.attr(
              "style"
            ) || ""
          ).toLowerCase();

        const text =
          this.cleanText(
            $div.text()
          );

        if (
          !text
        ) {
          return;
        }

        if (
          style.includes(
            "text-align:left"
          )
        ) {
          left =
            left || text;
        }

        if (
          style.includes(
            "text-align:right"
          )
        ) {
          right =
            right || text;
        }
      }
    );

    return {
      left,

      center: "",

      right,
    };
  }

  // ============================================================
  // TIME PARSER
  // ============================================================

  parseTimeBlock(
    text
  ) {
    const clean =
      this.cleanText(
        text
      );

    if (
      !clean ||
      /\bSRC\b/i.test(
        clean
      )
    ) {
      return this.emptyTimeInfo();
    }

    const matches = [
      ...clean.matchAll(
        /\b(\d{1,2}:\d{2})\s*(\d{1,2}-[A-Za-z]{3}(?:-\d{4})?)?\*?/g
      ),
    ];

    if (
      !matches.length
    ) {
      return this.emptyTimeInfo();
    }

    const scheduled =
      matches[0]?.[1] ||
      null;

    const scheduledDate =
      matches[0]?.[2] ||
      null;

    const actual =
      matches.length > 1
        ? matches[1]?.[1] ||
          null
        : null;

    const actualDate =
      matches.length > 1
        ? matches[1]?.[2] ||
          null
        : null;

    let status =
      "SCHEDULED";

    if (
      actual
    ) {
      const delay =
        this.calculateDelayMinutes(
          scheduled,
          actual
        );

      if (
        delay === null
      ) {
        status =
          "ACTUAL";
      } else if (
        delay > 0
      ) {
        status =
          "DELAYED";
      } else if (
        delay < 0
      ) {
        status =
          "EARLY";
      } else {
        status =
          "ON_TIME";
      }
    }

    return {
      scheduled,

      actual,

      date:
        actualDate ||
        scheduledDate ||
        null,

      status,
    };
  }

  emptyTimeInfo() {
    return {
      scheduled: null,

      actual: null,

      date: null,

      status: null,
    };
  }

  // ============================================================
  // PLATFORM
  // ============================================================

  extractPlatform(
    text
  ) {
    const match =
      text.match(
        /\bPF\s*([A-Z0-9-]+)\*?/i
      );

    return match
      ? match[1]
      : null;
  }

  // ============================================================
  // DISTANCE
  // ============================================================

  extractDistance(
    text
  ) {
    const match =
      text.match(
        /\b(\d+(?:\.\d+)?)\s*KMs?\b/i
      );

    if (
      !match
    ) {
      return null;
    }

    return Number(
      match[1]
    );
  }

  // ============================================================
  // RUNNING STATUS
  // ============================================================

  parseRunningStatus(
    $,
    journeyDate
  ) {
    const bodyText =
      this.cleanText(
        $("body").text()
      );

    /*
     * ----------------------------------------------------------
     * DEPARTED FROM
     * ----------------------------------------------------------
     */

    const departureRegex =
      /Departed\s+from\s+(.+?)\s*\(([A-Z0-9]{2,8})\)\s+(?:on|at)\s+(.+?)(?=\s+(?:Upcoming\s+Station|Current\s+Position|Arrived\s+at)|$)/gi;

    const departureMatches = [
      ...bodyText.matchAll(
        departureRegex
      ),
    ];

    let currentStation =
      null;

    let currentStationCode =
      null;

    let currentTime =
      null;

    for (
      const match of departureMatches
    ) {
      const datePart =
        this.extractDateFromText(
          match[3]
        );

      if (
        journeyDate &&
        datePart &&
        !this.datesMatch(
          datePart,
          journeyDate
        )
      ) {
        continue;
      }

      currentStation =
        this.cleanStationName(
          match[1]
        );

      currentStationCode =
        match[2]
          .toUpperCase();

      /*
       * Extract only:
       *
       * 16:01 16-Sep
       *
       * instead of the entire following page content.
       */

      const timeMatch =
        match[3].match(
          /\b(\d{1,2}:\d{2})\s*(\d{1,2}-[A-Za-z]{3}(?:-\d{4})?)?/i
        );

      currentTime =
        timeMatch
          ? (
              `${timeMatch[1]} ` +
              `${timeMatch[2] || ""}`
            ).trim()
          : this.cleanText(
              match[3]
            );

      break;
    }

    /*
     * ----------------------------------------------------------
     * ARRIVED AT
     * ----------------------------------------------------------
     */

    if (
      !currentStationCode
    ) {
      const arrivalRegex =
        /Arrived\s+at\s+(.+?)\s*\(([A-Z0-9]{2,8})\)\s+(?:on|at)\s+(.+?)(?=\s+(?:Upcoming\s+Station|Current\s+Position|Departed\s+from)|$)/gi;

      const arrivalMatches = [
        ...bodyText.matchAll(
          arrivalRegex
        ),
      ];

      for (
        const match of arrivalMatches
      ) {
        const datePart =
          this.extractDateFromText(
            match[3]
          );

        if (
          journeyDate &&
          datePart &&
          !this.datesMatch(
            datePart,
            journeyDate
          )
        ) {
          continue;
        }

        currentStation =
          this.cleanStationName(
            match[1]
          );

        currentStationCode =
          match[2]
            .toUpperCase();

        const timeMatch =
          match[3].match(
            /\b(\d{1,2}:\d{2})\s*(\d{1,2}-[A-Za-z]{3}(?:-\d{4})?)?/i
          );

        currentTime =
          timeMatch
            ? (
                `${timeMatch[1]} ` +
                `${timeMatch[2] || ""}`
              ).trim()
            : this.cleanText(
                match[3]
              );

        break;
      }
    }

    /*
     * ----------------------------------------------------------
     * UPCOMING STATION
     * ----------------------------------------------------------
     */

    let upcomingStation =
      null;

    let upcomingStationCode =
      null;

    const upcomingRegex =
      /Upcoming\s+Station\s*[:\-]?\s*(.+?)\s*\(([A-Z0-9]{2,8})\)/i;

    const upcomingMatch =
      bodyText.match(
        upcomingRegex
      );

    if (
      upcomingMatch
    ) {
      upcomingStation =
        this.cleanStationName(
          upcomingMatch[1]
        );

      upcomingStationCode =
        upcomingMatch[2]
          .toUpperCase();
    }

    /*
     * ----------------------------------------------------------
     * NOT STARTED
     * ----------------------------------------------------------
     *
     * Only use this when there is no matching
     * departed/arrived status for the requested date.
     */

    if (
      !currentStationCode &&
      !upcomingStationCode &&
      /Yet to start from its source/i.test(
        bodyText
      )
    ) {
      const startDate =
        this.extractStartDate($);

      if (
        !journeyDate ||
        !startDate ||
        this.datesMatch(
          startDate,
          journeyDate
        )
      ) {
        return {
          state:
            "NOT_STARTED",

          currentStation:
            null,

          currentStationCode:
            null,

          currentTime:
            null,

          upcomingStation:
            null,

          upcomingStationCode:
            null,

          journeyDate:
            journeyDate || null,

          rawText:
            "Yet to start from its source",
        };
      }
    }

    /*
     * ----------------------------------------------------------
     * RETURN STATUS
     * ----------------------------------------------------------
     */

    if (
      currentStationCode ||
      upcomingStationCode
    ) {
      return {
        state:
          currentStationCode
            ? "DEPARTED"
            : "RUNNING",

        currentStation,

        currentStationCode,

        currentTime,

        upcomingStation,

        upcomingStationCode,

        journeyDate:
          journeyDate || null,

        rawText:
          this.extractStatusContext(
            bodyText,
            currentStationCode ||
              upcomingStationCode
          ),
      };
    }

    return {
      state:
        "UNKNOWN",

      currentStation:
        null,

      currentStationCode:
        null,

      currentTime:
        null,

      upcomingStation:
        null,

      upcomingStationCode:
        null,

      journeyDate:
        journeyDate || null,

      rawText:
        null,
    };
  }

  // ============================================================
  // DATE HELPERS
  // ============================================================

  extractDateFromText(
    text
  ) {
    if (
      !text
    ) {
      return null;
    }

    const match =
      text.match(
        /\b(\d{1,2}-[A-Za-z]{3}(?:-\d{4})?)\b/
      );

    return match
      ? match[1]
      : null;
  }

  datesMatch(
    first,
    second
  ) {
    const a =
      this.normalizeDate(
        first
      );

    const b =
      this.normalizeDate(
        second
      );

    if (
      !a ||
      !b
    ) {
      return false;
    }

    const aParts =
      a.split("-");

    const bParts =
      b.split("-");

    /*
     * 16-Sep vs 16-Sep-2026
     */

    if (
      aParts.length === 2 &&
      bParts.length === 3
    ) {
      return (
        aParts[0] ===
          bParts[0] &&
        aParts[1] ===
          bParts[1]
      );
    }

    if (
      aParts.length === 3 &&
      bParts.length === 2
    ) {
      return (
        aParts[0] ===
          bParts[0] &&
        aParts[1] ===
          bParts[1]
      );
    }

    return a === b;
  }

  // ============================================================
  // DELAY
  // ============================================================

  calculateDelayMinutes(
    scheduled,
    actual
  ) {
    if (
      !scheduled ||
      !actual
    ) {
      return null;
    }

    const scheduledMinutes =
      this.timeToMinutes(
        scheduled
      );

    const actualMinutes =
      this.timeToMinutes(
        actual
      );

    if (
      scheduledMinutes === null ||
      actualMinutes === null
    ) {
      return null;
    }

    let difference =
      actualMinutes -
      scheduledMinutes;

    /*
     * Midnight crossing.
     */

    if (
      difference < -720
    ) {
      difference += 1440;
    }

    if (
      difference > 720
    ) {
      difference -= 1440;
    }

    return difference;
  }

  timeToMinutes(
    time
  ) {
    const match =
      String(time).match(
        /^(\d{1,2}):(\d{2})$/
      );

    if (
      !match
    ) {
      return null;
    }

    const hours =
      Number(
        match[1]
      );

    const minutes =
      Number(
        match[2]
      );

    if (
      hours < 0 ||
      hours > 23 ||
      minutes < 0 ||
      minutes > 59
    ) {
      return null;
    }

    return (
      hours * 60 +
      minutes
    );
  }

  // ============================================================
  // STATUS CONTEXT
  // ============================================================

  extractStatusContext(
    text,
    keyword
  ) {
    if (
      !text ||
      !keyword
    ) {
      return null;
    }

    const index =
      text
        .toLowerCase()
        .indexOf(
          String(
            keyword
          ).toLowerCase()
        );

    if (
      index === -1
    ) {
      return null;
    }

    const start =
      Math.max(
        0,
        index - 150
      );

    const end =
      Math.min(
        text.length,
        index + 450
      );

    return text
      .slice(
        start,
        end
      )
      .trim();
  }

  // ============================================================
  // TEXT HELPERS
  // ============================================================

  cleanText(
    value
  ) {
    return String(
      value || ""
    )
      .replace(
        /\u00a0/g,
        " "
      )
      .replace(
        /\s+/g,
        " "
      )
      .trim();
  }

  cleanStationName(
    value
  ) {
    return this.cleanText(
      value
    )
      .replace(
        /\s+/g,
        " "
      )
      .trim();
  }
}

module.exports = new NTESParser();